# 🌿 Paulista Verde — como publicar no GitHub Pages

O projeto foi preparado para **GitHub Pages** e funciona como um site **estático** (HTML + CSS + JavaScript), sem instalar pacotes ou rodar servidores na hospedagem.

## 1. Criar o repositório

1. Entre em https://github.com/new e faça login na sua conta.
2. Nome sugerido: `paulista-verde`.
3. Selecione **Public** para usar GitHub Pages no plano gratuito.
4. Clique em **Create repository**.

## 2. Enviar o projeto

1. Extraia o ZIP no seu computador.
2. No repositório, clique em **Add file → Upload files** (em repositórios vazios, use **uploading an existing file**).
3. Envie **todos os arquivos que estão dentro da pasta**, inclusive `index.html`, `style.css`, `script.js`, `config.js`, `banco_supabase.sql`, `README.md` e `.nojekyll`.
4. IMPORTANTE: `index.html` deve ficar **na raiz do repositório**. **Não envie apenas o ZIP** e não deixe o `index.html` dentro de outra pasta.
5. Clique em **Commit changes**.

## 3. Ativar o GitHub Pages

1. No repositório, abra **Settings → Pages**.
2. Em **Build and deployment**, escolha **Source: Deploy from a branch**.
3. Em **Branch**, selecione `main` e a pasta `/(root)`.
4. Clique em **Save**.
5. Abra o link exibido pelo GitHub Pages quando a publicação terminar. Formato esperado: `https://SEU-USUARIO.github.io/paulista-verde/`.

O endereço depende do **nome de usuário e do repositório**. A publicação pode levar alguns minutos. Instruções oficiais: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## 4. Testar a publicação

- O menu deve navegar entre as seções.
- Pesquisar `Aceroleira` deve filtrar a lista.
- O filtro `Hortaliças` deve exibir apenas hortaliças.
- Os quatro pontos marcados como **EXEMPLO FICTÍCIO** são apenas uma demonstração; **não representam locais reais de coleta**.
- O mapa exige internet e utiliza Leaflet + OpenStreetMap.
- O botão **Minha localização** deve pedir autorização ao navegador. O site no GitHub Pages usa **HTTPS**, exigido pelo GPS.
- Sem banco configurado, um cadastro fica **somente no navegador** de quem cadastrou.

## 5. Se quiser cadastros compartilhados em todos os celulares

**GitHub Pages hospeda a página, não um banco de dados.** Para compartilhar os dados, é preciso configurar o Supabase:

1. Crie um projeto em https://supabase.com/.
2. Copie o conteúdo de `banco_supabase.sql` e execute em **SQL Editor**.
3. Abra `config.js` e preencha `supabaseUrl` e `supabaseKey` **somente com a chave publicável**, nunca com chave secreta.
4. Faça commit da alteração no GitHub. Depois, teste em dois aparelhos.

⚠️ **Segurança:** esse banco opcional é uma demonstração com leitura e cadastro anônimos. Sem autenticação, moderação e proteção contra spam, **não deve ser aberto para utilização ampla**. Não publique endereço de residências nem dados pessoais, e obtenha autorização para pontos em áreas privadas.

## 6. Atualizar o site

Edite o arquivo desejado diretamente no repositório (ícone de lápis) e clique em **Commit changes**. O GitHub Pages publicará as alterações da branch `main`.

## 7. Uso de IA na Maratona DevImpacto

Conforme o regulamento informado pela equipe, **não é permitida a submissão de lógica central escrita integralmente por IA**. Esta base foi produzida com IA e precisa servir para estudo, revisão e reimplementação pelos estudantes. Declarem o auxílio da IA no formulário e no pitch conforme as regras e apresentem apenas o trabalho que realmente desenvolveram.
